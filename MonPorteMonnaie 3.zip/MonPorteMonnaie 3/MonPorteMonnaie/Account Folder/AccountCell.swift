//
//  AccountCell.swift
//  MonPorteMonnaie
//
//  Created by Adeline GIROIX on 26/07/2023.
//

import SwiftUI

struct AccountCell: View {
    
    let calculationsService = CalculationsService()
    
    @ObservedObject var account: Account
    
    
    var body: some View {
        HStack {
            Image(account.iconName)
                .resizable()
                .padding(4)
                .frame(width: 50, height: 50)
            VStack(alignment: .leading, spacing: 4 ){
                Text(account.name)
                    .font(.title2)
                    .foregroundColor(.primary)
                Text(calculationsService.calculationOfBalanceOfOneAccount(currentAccount: account))
                    .foregroundColor(account.amount >= 0.00 ? .green : Color(.red))
                    .font(.title3)
                    .foregroundColor(Color(white: 0.4))
            }
            Spacer()
            Button {
                account.isFavourite.toggle()
            } label: {
                Image(systemName: account.isFavourite ? "star.fill" : "star")
                    .resizable()
                    .foregroundColor(account.isFavourite ? .yellow : Color(white: 0.2))
                    .frame(width: 30, height: 30)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(Color.white)
        .cornerRadius(16)
        .border(Color.blue, width: 2) // Bordure
    }
}



struct AccountCell_Previews: PreviewProvider {
      
    static let previewAccount = Account(iconName: "icon_002", name: "Paypal", initialAmount: 2222.22, transactions: previewTransactions, currency: .euro)
    
    static var previews: some View {
        AccountCell(account: previewAccount)
            .padding()
            .background(Color("grey"))
            .previewLayout(.sizeThatFits)
    }
}
