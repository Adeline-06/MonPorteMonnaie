//
//  AccountCreationView.swift
//  MonPorteMonnaie
//
//  Created by Adeline GIROIX on 06/08/2023.
//

import SwiftUI

struct AccountCreationView: View {
    
    let calculationsService = CalculationsService()
    
    @Environment(\.presentationMode) var presentationMode
    
    @State private var accountName: String = ""
    @State private var amount = ""
    @State private var selactedCurrency: Currency = .euro
    @State private var selectedIcon: String = "icon_002"
    
    var onAccountCreated: (Account) -> Void
    
    var body: some View {
        VStack(spacing: 32) {
            VStack(spacing: 16) {
                Text(accountName == "" ? "Nouveau Compte" : accountName)
                    .font(.system(size: 32, weight: .bold))
                    .padding(.top, 32)
                Text(calculationsService.calculationOfNewAccountAmount(amountEntered: amount))
                    .font(.system(size: 20, weight: .light))
                    .foregroundColor(Color(white: 0.41))
            }
            VStack(alignment: .leading) {
                Text("Nom :")
                    .font(.title2)
                    .bold()
                    .padding(.top, 32)
                TextField("Ex : Paypal...", text: $accountName)
                    .submitLabel(.done)
                    .padding(12)
                    .padding(.horizontal, 12)
                    .background(Color.white)
                    .cornerRadius(.infinity)
            }
            VStack(alignment: .leading) {
                Text("Icone")
                    .font(.title2)
                    .bold()
                IconSelector(selectedIcon: $selectedIcon)
                    .padding(.horizontal, -16)
            }
            VStack(alignment: .leading) {
                Text("Solde Initial")
                    .font(.title2)
                    .bold()
                HStack {
                    TextField("Ex : 123,45 \(selactedCurrency.rawValue)", text: $amount)
                        .padding(12)
                        .padding(.horizontal, 12)
                        .keyboardType(.numbersAndPunctuation)
                        .submitLabel(.done)
                    CurrencySelector(selectedCurrency: $selactedCurrency)
                        .foregroundColor(Color(.darkGray))
                        .padding(4)
                }
                .background(Color.white)
                .cornerRadius(.infinity)
            }
            Spacer()
            MainButton(title: "Créer") {
                let newAccount = Account(
                    iconName: selectedIcon,
                    name: accountName,
                    initialAmount: Float(amount) ?? 0,
                    transactions: [],
                    currency: selactedCurrency
                )
                onAccountCreated(newAccount)
                presentationMode.wrappedValue.dismiss()
            }
        }
        .padding()
        .background(Color("grey"))
    }
}

struct accountCreatioView_Previews: PreviewProvider {
    static var previews: some View {
        AccountCreationView { _ in
            return
        }
    }
}
