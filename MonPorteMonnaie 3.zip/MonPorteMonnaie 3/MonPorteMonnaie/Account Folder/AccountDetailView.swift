//
//  AccountDetailView.swift
//  MonPorteMonnaie
//
//  Created by Adeline GIROIX on 09/08/2023.
//

import SwiftUI

struct AccountDetailView: View {
    
    let calculation = CalculationsService()
    let dataFileManager = DataFileManager()
    
    @EnvironmentObject var accountsList: AccountsList
    @Environment(\.presentationMode) var presentationMode
    @ObservedObject var account: Account
//    @State private var isPresentingNewTransactionScreen = false
    @State private var isShowingAccountDeletionAlert = false
    @State private var isShowingTransactionAlert = false
    @State private var selectedTransactionToDelete: Transaction? = nil
    @State private var isEditingMode = false
    @FocusState private var focusedField: Field?
    
    @Binding var grantTotalAccounts: String // Ajoutez une liaison pour grantTotalAccounts
    
    var onCompletion: ((Bool) -> Void)?
    
    var body: some View {
        ScrollView {
            VStack {
                Button {
                    isEditingMode = true
                    focusedField = .name
                } label: {
                    Label("Renommer ce compte", systemImage: "pencil")
                        .foregroundColor(Color.blue)
                }
            }
            VStack {
                Button(role: .destructive) {
                    isShowingAccountDeletionAlert = true
                } label: {
                    Label("Supprimer ce compte", systemImage: "trash")
                }
            }
            .alert(isPresented: $isShowingAccountDeletionAlert) {
                Alert(
                    title: Text("Attention !"),
                    message: Text("Le compte va être supprimé\nToutes les transactions liées seront perdues."),
                    primaryButton: .destructive(Text("Supprimer"), action: {
                        // D'abord, supprimez le compte
                        accountsList.accounts.removeAll { element in
                            element.id == account.id
                        }
                        
                        // data saving
                        dataFileManager.dataFileSave(accounts: accountsList.accounts) { result in
                            if case .failure(let error) = result {
                                fatalError(error.localizedDescription)
                            } else {
                                // Indiquez le succès de l'opération en appelant la complétion
                                onCompletion?(true)
                                // Mettez à jour grantTotalAccounts avec la nouvelle valeur
                                grantTotalAccounts = calculation.calculationOfGrantTotalOfAllAccountsAmounts(currentAccountsList: accountsList)
                            }
                        }
                        
                        // Enfin, revenez à l'écran précédent
                        withAnimation {
                            presentationMode.wrappedValue.dismiss()
                        }
                    }),
                    secondaryButton: .cancel(Text("Annuler"))
                )
            }
            
//            .alert(isPresented: $isShowingAccountDeletionAlert) {
//                Alert(
//                    title: Text("Attention !"),
//                    message: Text("Le compte va être supprimé\nToutes les transactions liées seront perdues."),
//                    primaryButton: .destructive(Text("Supprimer"), action: {
//                        // D'abord, supprimez le compte
//                        accountsList.accounts.removeAll { element in
//                            element.id == account.id
//                        }
//
//                        // data saving
//                        dataFileManager.dataFileSave(accounts: accountsList.accounts) { result in
//
//                            if case .failure(let error) = result {
//                                      fatalError(error.localizedDescription)
//                                  } else {
//                                      // Indiquez le succès de l'opération en appelant la complétion
//                                      onCompletion?(true)
//                                  }
//                        }
//
//                        // Enfin, revenez à l'écran précédent
//                        withAnimation {
//                            presentationMode.wrappedValue.dismiss()
//                        }
//                    }),
//                    secondaryButton: .cancel(Text("Annuler"))
//                )
//            }
            VStack(spacing: 24) {
                HStack {
                    if isEditingMode {
                        TextField("Entrer un nom....", text: $account.name)
                            .font(.system(size: 32, weight: .bold))
                            .focused($focusedField, equals: .name)
                            .onChange(of: account.name) { newName in
                                // La valeur du TextField a été modifiée, déclenchez la sauvegarde
                                saveDataFile()
                            }
                    } else {
                        Text(account.name)
                            .font(.system(size: 32, weight: .bold))
                    }
                    Spacer()
//                  Text("\(String(format: "%.2f", account.amount)) \(account.currency.rawValue)")
                    Text(calculation.calculationTotalAmountOfOneAccount(currentAccount: account))
                    
                        .font(.system(size: 32, weight: .light))
                }
//                AccentButton(title: "+ Transaction", color: Color("purple")) {
//                    isPresentingNewTransactionScreen = true
//                }
                Divider()
                VStack(spacing: 16) {
                    if account.transactions.isEmpty {
                        Text("Aucune transaction enregistrée ...")
                            .font(.callout)
                            .foregroundColor(Color(white: 0.4))
                    }
                    ForEach(account.transactions) { transaction in
                        TransactionCell(transaction: transaction, onDelete: {
                            isShowingTransactionAlert = true
                            selectedTransactionToDelete = transaction
                        })
                    }
                    HStack {
                        Text("Solde initial :")
                            .font(.callout)
                            .foregroundColor(.black)
                        Text(calculation.calculationOfAnAccountInitialAmount(currentAccount: account))
                            .foregroundColor(account.amount >= 0.00 ? .green : Color(.red))
                            .font(.title3)
                    }
                    .foregroundColor(Color(white: 0.5))
                    .padding()
                }
                
                .alert(isPresented: $isShowingTransactionAlert) {
                    Alert(
                        title: Text("Attention !"),
                        message: Text("Suppression de la transaction\nCette action sera irréversible"),
                        primaryButton: .destructive(Text("Supprimer"), action: {
                            // Supprimez la transaction
                            withAnimation {
                                account.transactions.removeAll { transaction in
                                    selectedTransactionToDelete!.id == transaction.id
                                }
                            }
                            selectedTransactionToDelete = nil

                            // Utilisez DispatchQueue pour effectuer la sauvegarde des données de manière asynchrone
                            DispatchQueue.global(qos: .background).async {
                                dataFileManager.dataFileSave(accounts: accountsList.accounts) { result in
                                    if case .failure(let error) = result {
                                        fatalError(error.localizedDescription)
                                    } else {
                                        // Indiquez le succès de l'opération en appelant la complétion
                                                        onCompletion?(true)
                                                        // Mettez à jour grantTotalAccounts avec la nouvelle valeur
                                                        grantTotalAccounts = calculation.calculationOfGrantTotalOfAllAccountsAmounts(currentAccountsList: accountsList)
                                    }
                                }
                            }
                        }),
                        secondaryButton: .cancel(Text("Annuler"))
                    )
                }
                
                
//                .alert(isPresented: $isShowingTransactionAlert) {
//                    Alert(
//                        title: Text("Attention !"),
//                        message: Text("Suppression de la transaction\nCette action sera irréversible"),
//                        primaryButton: .destructive(Text("Supprimer"), action: {
//                            // Supprimez la transaction
//                            withAnimation {
//                                account.transactions.removeAll { transaction in
//                                    selectedTransactionToDelete!.id == transaction.id
//                                }
//                            }
//                            selectedTransactionToDelete = nil
//
//                            // Utilisez DispatchQueue pour effectuer la sauvegarde des données de manière asynchrone
//                            DispatchQueue.global(qos: .background).async {
//                                dataFileManager.dataFileSave(accounts: accountsList.accounts) { result in
//                                    if case .failure(let error) = result {
//                                        fatalError(error.localizedDescription)
//                                    }
//                                }
//                            }
//                        }),
//                        secondaryButton: .cancel(Text("Annuler"))
//                    )
//                }

            }
            .padding()
        }
        .background(Color("grey"))
//        .sheet(isPresented: $isPresentingNewTransactionScreen, content: {
//            TransactionCreationView()
//        })
    }
    
    func saveDataFile() {
        dataFileManager.dataFileSave(accounts: accountsList.accounts) { result in
            if case .failure(let error) = result {
                fatalError(error.localizedDescription)
            }
        }
    }
    
    private enum Field: Int, Hashable {
        case name
    }
    
}

//struct AccountDetailView_Previews: PreviewProvider {
//    static var previews: some View {
//        NavigationView {
//            AccountDetailView(dataModel: data, account: previewAccounts[0])
//        }
//    }
//}


//swiftui : lorsqu'une vue est appelée par une NavigationView, comment changer le bouton "Back" par "Retour" ?
//ChatGPT
//Pour personnaliser le texte du bouton de retour (back button) dans une vue SwiftUI lorsqu'elle est appelée par une NavigationView, vous pouvez utiliser la méthode navigationBarBackButtonHidden(_:) et la modifier à l'intérieur du NavigationView. Vous pouvez également utiliser navigationBarTitle(_:) pour personnaliser davantage le texte de la vue précédente.
//
//Voici un exemple de code pour changer le bouton de retour en "Retour" dans une vue SwiftUI :
//
//swift
//Copy code
//import SwiftUI
//
//struct ContentView: View {
//    var body: some View {
//        NavigationView {
//            NavigationLink("Aller à la vue suivante", destination: SecondView())
//                .navigationBarTitle("Page d'accueil", displayMode: .inline)
//        }
//    }
//}
//
//struct SecondView: View {
//    var body: some View {
//        Text("Ceci est la deuxième vue")
//            .navigationBarTitle("Deuxième Vue", displayMode: .inline)
//            .navigationBarBackButtonHidden(true) // Masque le bouton de retour par défaut
//            .navigationBarItems(leading: BackButton(label: "Retour")) // Affiche votre propre bouton "Retour"
//    }
//}
//
//struct BackButton: View {
//    let label: String
//
//    var body: some View {
//        Button(action: {
//            // Vous pouvez ajouter ici la logique pour effectuer l'action de retour personnalisée
//        }) {
//            HStack {
//                Image(systemName: "chevron.left") // Vous pouvez utiliser une icône de flèche vers la gauche ici
//                Text(label)
//            }
//        }
//    }
//}
//
//@main
//struct MyApp: App {
//    var body: some Scene {
//        WindowGroup {
//            ContentView()
//        }
//    }
//}
//Dans cet exemple, la SecondView utilise navigationBarBackButtonHidden(true) pour masquer le bouton de retour par défaut, puis ajoute un bouton personnalisé appelé BackButton qui affiche le texte "Retour". Vous pouvez personnaliser davantage ce bouton selon vos préférences en utilisant des images, des couleurs, des styles, etc.
