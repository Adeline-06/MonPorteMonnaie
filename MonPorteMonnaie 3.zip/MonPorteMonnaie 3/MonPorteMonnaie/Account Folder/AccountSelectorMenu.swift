//
//  AccountSelectorMenu.swift
//  MonPorteMonnaie
//
//  Created by Adeline GIROIX on 09/08/2023.
//

import SwiftUI

struct AccountSelectorMenu: View {
    
    let calculation = CalculationsService()
    
    let accountList: AccountsList
    @State private var isShowingAccountList: Bool = false
    @Binding var selectedAccountIndex: Int
    let onCreateAccountButtonPressed: () -> Void
    
    var body: some View {
        VStack() {
            Text("Sélectionner un compte :")
                .font(.system(size: 25, weight: .bold))
                .foregroundColor(Color(red: 0.5, green: 0.0, blue: 0.5, opacity: 0.5))
                .padding(8)
            VStack {
                Button {
                    withAnimation {
                        isShowingAccountList.toggle()
                    }
                } label: {
                    Image(systemName: isShowingAccountList
                          ? "multiply.circle"
                          : "ellipsis.circle.fill")
                    .font(.system(size: 32))
                    .foregroundColor(Color(.red))
                }

//                Spacer()
//                Button {
//                    withAnimation {
//                        isShowingAccountList.toggle()
//                    }
//                } label: {
//                    Image(systemName: isShowingAccountList
//                          ? "multiply.circle"
//                          : "ellipsis.circle.fill")
//                    .font(.system(size: 32))
//                    .foregroundColor(Color(.red))
//                    .padding(4)
//                }
            }
            .padding()
            if isShowingAccountList {
                ForEach(accountList.accounts) { account in

                    Divider()
                    HStack {
                        Text(account.name)
                            .foregroundColor(.black)
                            .font(.title2)
                            .bold()
                        Text(calculation.calculationOfAccountSelectorAmount(currentAccount: account)
                        ).foregroundColor(account.amount >= 0.00 ? .green : Color(.red))
                            .font(.title3)
                        //
                        
                    }
                    .padding(12)
                    .padding(.horizontal, 12)
                    .onTapGesture {
                        selectedAccountIndex = accountList.accounts.firstIndex
                        { $0.id == account.id }!
                        withAnimation {
                            isShowingAccountList = false
                        }
                    }
                }
                Divider()
                Button {
                    onCreateAccountButtonPressed()
                } label: {
                    Text("Créer un nouveau compte.")
                        .foregroundColor(Color.blue)
                        .padding(12)
                        .padding(.horizontal, 12)
                }
            }
        }
        .background(Color.white)
        .cornerRadius(22)
    }
}

//struct AccountSelectorMenu_Previews: PreviewProvider {
//    static var previews: some View {
//        AccountSelectorMenu(
//            accountList: AccountsList(accounts: previewAccounts),
//            selectedAccountIndex: .constant(0), onCreateAccountButtonPressed: {}
//        )
//        .padding()
//        .background(Color("grey"))
//        .previewLayout(.sizeThatFits)
//    }
//}
