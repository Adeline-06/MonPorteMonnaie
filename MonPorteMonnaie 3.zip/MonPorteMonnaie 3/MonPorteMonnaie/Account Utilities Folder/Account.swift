//
//  Account.swift
//  MonPorteMonnaie
//
//  Created by Adeline GIROIX on 26/07/2023.
//

import Foundation

/// Classe qui représente les compte, elle stocke des infos, elle rend les vues réactives aux changements
/// Class that represents accounts, it stores information, it makes views responsive to changes
class Account: Identifiable, ObservableObject, Codable {
    
    let calculationsService = CalculationsService()
    
    var id = UUID()
    let iconName: String
    @Published var name: String
    let initialAmount: Float
    @Published var transactions: [Transaction]
    let currency: Currency
    
    /// Propriété calculée
    /// computed propertie
    var amount: Float {
        calculationsService.calculationOfComputedPropertieAccountAmount(currentAccount: self)
    }
    
    @Published var isFavourite: Bool
    
    init(iconName: String, name: String, initialAmount: Float, transactions: [Transaction], currency: Currency, isFavourite: Bool = false) {
        self.iconName = iconName
        self.name = name
        self.initialAmount = initialAmount
        self.transactions = transactions
        self.currency = currency
        self.isFavourite = isFavourite
    }
    
    required init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.id = try container.decode(UUID.self, forKey: .id)
        self.iconName = try container.decode(String.self, forKey: .iconName)
        self.name = try container.decode(String.self, forKey: .name)
        self.initialAmount = try container.decode(Float.self, forKey: .initialAmount)
        self.transactions = try container.decode([Transaction].self, forKey: .transactions)
        self.currency = try container.decode(Currency.self, forKey: .currency)
        self.isFavourite = try container.decode(Bool.self, forKey: .isFavourite)
    }
    
    enum CodingKeys: CodingKey {
        case id
        case iconName
        case name
        case initialAmount
        case transactions
        case currency
        case isFavourite
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(id, forKey: .id)
        try container.encode(iconName, forKey: .iconName)
        try container.encode(name, forKey: .name)
        try container.encode(initialAmount, forKey: .initialAmount)
        try container.encode(transactions, forKey: .transactions)
        try container.encode(currency.rawValue, forKey: .currency)
        try container.encode(isFavourite, forKey: .isFavourite)
    }
}
