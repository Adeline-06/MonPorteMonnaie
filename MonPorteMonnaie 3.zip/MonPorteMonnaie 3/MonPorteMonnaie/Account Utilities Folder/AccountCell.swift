//
//  AccountCell.swift
//  MonPorteMonnaie
//
//  Created by Adeline GIROIX on 26/07/2023.
//

import SwiftUI

/// Utilisée pour afficher les détails d'un compte financier, y compris son icône, son nom, son solde, et permet à l'utilisateur de le marquer comme favori.
/// Used to display details of a financial account, including its icon, name, balance, and allows the user to mark it as favorite.
struct AccountCell: View {
    
    let calculationsService = CalculationsService()
    
    ///Cette vue observe l'objet account de type Account. Cela signifie que cette vue sera automatiquement actualisée dès que des modifications sont apportées à l'objet account, grâce à l'attribut @ObservedObject
    ///This view observes the account object of type Account. This means that this view will be automatically refreshed as soon as changes are made to the account object, thanks to the @ObservedObject attribute
    @ObservedObject var account: Account
    
    
    var body: some View {
        HStack {
            Image(account.iconName)
                .resizable()
                .padding(4)
                .frame(width: 50, height: 50)
            VStack(alignment: .leading, spacing: 4 ){
                Text(account.name)
                    .font(.title2)
                    .foregroundColor(.primary)
                Text(calculationsService.calculationOfBalanceOfOneAccount(currentAccount: account))
                    .foregroundColor(foregroundColorText(account.amount))
                    .font(.title3)
                    .foregroundColor(Color(white: 0.4))
            }
            Spacer()
            Button {
                account.isFavourite.toggle()
            } label: {
                Image(systemName: account.isFavourite ? "star.fill" : "star")
                    .resizable()
                    .foregroundColor(account.isFavourite ? .yellow : Color(white: 0.2))
                    .frame(width: 30, height: 30)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(Color.white)
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(Color.blue, lineWidth: 1)
        )
    }
    
    
    func foregroundColorText(_ value: Float) -> Color {
        if value == 0.00 {
            return .black
        } else if value >= 0.00 {
            return .green
        } else {
            return Color(.red)
        }
    }
    
}
