//
//  IconSelector.swift
//  MonPorteMonnaie
//
//  Created by Adeline GIROIX on 07/08/2023.
//

import SwiftUI

struct AccountSelectedIcon: View {
    
    @Binding var selectedIcon: String
    
    private let icons = [
        "icon_001",
        "icon_002",
        "icon_003",
        "icon_004",
        "icon_005",
        "icon_006",
        "icon_007",
    ]
    
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack {
                ForEach(icons, id: \.self) { iconName in
                    Button {
                        selectedIcon = iconName
                    } label: {
                        Circle()
                            .frame(width: 60, height: 60)
                            .foregroundColor(iconName == selectedIcon ? Color("cian") : Color("purple"))
                            .overlay {
                                Image(iconName)
                                    .resizable()
                                    .renderingMode(.template)
                                    .foregroundColor(iconName == selectedIcon ? .black : .black)
                                    .frame(width: 35, height: 35)
                            }
                    }
                }
            }
        }
    }
}
