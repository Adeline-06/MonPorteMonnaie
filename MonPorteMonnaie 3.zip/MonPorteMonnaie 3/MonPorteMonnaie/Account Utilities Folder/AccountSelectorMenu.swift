//
//  AccountSelectorMenu.swift
//  MonPorteMonnaie
//
//  Created by Adeline GIROIX on 09/08/2023.
//

import SwiftUI

struct AccountSelectorMenu: View {
    
    let calculationsService = CalculationsService()
    
    let accountList: AccountsList
    @State private var isShowingAccountList: Bool = false
    @Binding var selectedAccountIndex: Int
    let onCreateAccountButtonPressed: () -> Void
    
    var body: some View {
        VStack() {
            VStack {
                Text("Sélectionner un compte :")
                    .font(.system(size: 22, weight: .bold))
                    .foregroundColor(selectedAccountIndex == -1 ? .red : Color(.gray))
                    .padding()
                    .padding(.bottom, -18)
            }
            VStack {
                Button {
                    withAnimation {
                        isShowingAccountList.toggle()
                    }
                } label: {
                    Image(systemName: isShowingAccountList
                          ? "multiply.circle"
                          : "ellipsis.circle.fill")
                    .font(.system(size: 32))
                    .foregroundColor(selectedAccountIndex == -1 ? .red : Color("purple"))
                }
            }
            .padding()
            if isShowingAccountList {
                ForEach(accountList.accounts) { account in
                    HStack {
                        Text(account.name)
                            .foregroundColor(.black)
                            .font(.system(size: 24, weight: .bold))
                        Text(calculationsService.calculationOfAccountSelectorAmount(currentAccount: account)
                        )
                        .font(.system(size: 24, weight: .bold))
                        .foregroundColor(foregroundColorText(account.amount))
                    }
                    .padding(12)
                    .padding(.horizontal, 12)
                    .onTapGesture {
                        selectedAccountIndex = accountList.accounts.firstIndex
                        { $0.id == account.id }!
                        withAnimation {
                            isShowingAccountList = false
                        }
                    }
                }
                Button {
                    onCreateAccountButtonPressed()
                } label: {
                    Text("Créer un nouveau compte.")
                        .foregroundColor(Color.blue)
                        .padding(12)
                        .padding(.horizontal, 12)
                }
            }
        }
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(Color.blue, lineWidth: 1)
        )
        .background(Color.white)
    }
    
    
    func foregroundColorText(_ value: Float) -> Color {
        if value == 0 {
            return .black
        } else if value == 0 {
            return .black
        } else if value > 0 {
            return .green
        } else {
            return Color(.red)
        }
    }
    
}
