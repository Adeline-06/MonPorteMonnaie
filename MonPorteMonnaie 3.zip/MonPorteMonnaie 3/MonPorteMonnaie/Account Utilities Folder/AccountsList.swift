//
//  AccountList.swift
//  MonPorteMonnaie
//
//  Created by Adeline GIROIX on 08/08/2023.
//

import Foundation

/// Utilisée pour stocker et gérer une liste de comptes, elle sera observés par les vues
/// Used to store and manage a list of accounts, it will be observed by the views
class AccountsList: ObservableObject {
    
    /// Cette propriété publiée (@Published) est un tableau de comptes financiers (Account). Elle permet de stocker la liste des comptes gérés par cette classe.
    /// This published property (@Published) is a table of financial accounts (Account). It allows you to store the list of accounts managed by this class.
    @Published var accounts: [Account]
    
    init(accounts: [Account] = []) {
        self.accounts = accounts
    }
}


