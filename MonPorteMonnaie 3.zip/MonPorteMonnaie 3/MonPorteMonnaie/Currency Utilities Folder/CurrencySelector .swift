//
//  CurrencySelector .swift
//  MonPorteMonnaie
//
//  Created by Adeline GIROIX on 01/08/2023.
//

import SwiftUI

struct CurrencySelector: View {
    
    @Binding var selectedCurrency: Currency
    @State private var isDSelected = true
    private let currencies = Currency.allCases
    
    var body: some View {
        
        let currencyIndices = Array(currencies.indices)
        
        ZStack {
//            ForEach(currencies.indices) { index in
            ForEach(currencyIndices, id: \.self) { index in
                Image(systemName: selectedCurrency == currencies[index]
                      ? currencies[index].filledIconName
                      : currencies[index].iconName
                )
                .font(.system(size: 32))
                .offset(x: isDSelected
                        ? -CGFloat(index) * 40 : 0 )
                .opacity(selectedCurrency == currencies[index] || isDSelected ? 1 : 0 )
                .onTapGesture {
                    if isDSelected {
                        selectedCurrency = currencies[index]
                    }
                    withAnimation(.easeInOut(duration: 0.2)) {
                        isDSelected.toggle()
                    }
                }
            }
        }
    }
}


