//
//  Alert.swift
//  MonPorteMonnaie
//
//  Created by Adeline GIROIX on 25/09/2023.
//

import SwiftUI


struct AlertData: Identifiable { // Créez un objet Identifiable pour l'alerte
    var id = UUID()
    var title: String
    var message: String
}
