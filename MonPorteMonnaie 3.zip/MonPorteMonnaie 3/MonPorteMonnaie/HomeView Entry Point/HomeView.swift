//
//  HomeView.swift
//  MonPorteMonnaie
//
//  Created by Adeline GIROIX on 19/07/2023.
//

import SwiftUI

struct HomeView: View {
    
    let calculationsService = CalculationsService()
    let dataFileManager = DataFileManager()
    
    @Environment(\.scenePhase) private var scenePhase
    
    @State private var isPresentingNewAccountScreen = false
    @State private var isPresentingNewTransactionScreen = false
    @State private var isShowingFavouritesOnly = false
    @State private var isShowingNoAccountAlert = false
    
    @StateObject var accountsList = AccountsList()
    
    @State private var grantTotalAccounts = ""
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 8) {
                    Text("Solde global en cours:")
                        .font(.title2)
                        .bold()
//                    Text(calculationsService.calculationOfGrantTotalOfAllAccountsAmounts(currentAccountsList: accountsList))
//                        .font(.system(size: 32, weight: .bold))
                    
                    Text(grantTotalAccounts)
                        .font(.system(size: 32, weight: .bold))
                        .foregroundColor(grantTotalAccounts >= "0.00" ? .green : Color(.red))
                }
                .padding(24)
                
                HStack(spacing: 16) {
                    AccentButton(title: "Comptes", color: Color("orange")) {
                        isPresentingNewAccountScreen = true
                    }
                    .border(Color.blue, width: 2) // Ajoute une bordure bleue de 2 points d'épaisseur au bouton
                    AccentButton(title: "Transactions", color: Color("purple")) {
                        if accountsList.accounts.isEmpty {
                            isShowingNoAccountAlert = true
                        } else {
                            isPresentingNewTransactionScreen = true
                        }
                    }
                    .border(Color.blue, width: 2) // Ajoute une bordure bleue de 2 points d'épaisseur au bouton
                }
                .padding(24)
                VStack(alignment: .leading) {
                    HStack {
                        Text("Mes Comptes")
                            .padding()
                        Spacer()
                        Button {
                            withAnimation {
                                isShowingFavouritesOnly.toggle()
                            }
                        } label: {
                            Image(systemName: isShowingFavouritesOnly ? "star.fill" : "star")
                                .foregroundColor(isShowingFavouritesOnly ? .yellow : Color(white: 0.2))
                                .padding(.trailing)
                        }
                    }
                    .cornerRadius(12) // Coins arrondis
                    .frame(maxWidth: .infinity) // Pour centrer horizontalement
                    .border(Color.blue, width: 2) // Ajoute une bordure bleue de 2 points d'épaisseur au bouton
                    .font(.title)
                    .bold()
                    .background(Color(red: 0.5, green: 0.0, blue: 0.5, opacity: 0.8))
                    .foregroundColor(.white)
                    .border(Color.blue, width: 2) // Bordure
                    if accountsList.accounts.count > 0 {
                        VStack (spacing: 16) {
                            ForEach(accountsList.accounts) { account in
                                if !isShowingFavouritesOnly || account.isFavourite {
//                                    NavigationLink {
//                                        withAnimation {
//
//
//                                            AccountDetailView(account: account)
//                                                .environmentObject(accountsList)
//                                        }
                                    NavigationLink {
                                        withAnimation {
                                            AccountDetailView(account: account, grantTotalAccounts: $grantTotalAccounts) { success in
                                                
                                                if success {
                                                    // Gestion de la complétion en cas de succès
                                                    print("succès AccountDetailView")
                                                    // Par exemple, vous pouvez mettre à jour l'interface utilisateur ou effectuer d'autres actions ici.
                                                } else {
                                                    // Gestion de la complétion en cas d'échec
                                                }
                                            }
                                            .environmentObject(accountsList)
                                        }
                                        
                                    } label: {
                                        AccountCell(account: account)
                                    }
                                }
                            }
                        }
                        .padding()
                    } else {
                        Text("Pas de compte enregistré...")
                            .padding(32)
                            .frame(maxWidth: .infinity)
                    }
                }
                .padding(24)
            }
            .background(Color("grey"))
            .sheet(isPresented: $isPresentingNewAccountScreen) {
                AccountCreationView() { newAccount in
                    accountsList.accounts.append(newAccount)
                    
                    self.calculGrantTotalAccounts()
                    
                    dataFileManager.dataFileSave(accounts: accountsList.accounts) { result in
                        if case .failure(let error) = result {
                            fatalError(error.localizedDescription)
                        }
                    }
                }
                
                
            }
            .alert(isPresented: $isShowingNoAccountAlert) {
                Alert(
                    title: Text("Attention !"),
                    message: Text("Aucun compte existant pour pouvoir associer des transactions..."),
                    primaryButton: .default(Text("Créer un compte"), action: {
                        isPresentingNewAccountScreen = true
                    }), secondaryButton: .default(Text("Annuler")))
            }
            //            .sheet(isPresented: $isPresentingNewTransactionScreen) {
            //                TransactionCreationView()
            //                    .environmentObject(accountsList)
            //            }
            .sheet(isPresented: $isPresentingNewTransactionScreen) {
                TransactionCreationView { success in
                    if success {
                        // Gestion de la complétion en cas de succès
                        print("TransactionCreationView")
                        self.calculGrantTotalAccounts()
                        print("grantTotalAccounts : \(grantTotalAccounts)")
                        // Par exemple, vous pouvez mettre à jour l'interface utilisateur ou effectuer d'autres actions ici.
                    } else {
                        // Gestion de la complétion en cas d'échec
//                        print("Erreur dataFileManager.dataFileSave : completionHandler?(false)")
                    }
                }
                .environmentObject(accountsList)
            }
            
            
        }
//        .accentColor(.black)
        .onChange(of: scenePhase) { phase in
            if phase == .inactive {
                DispatchQueue.global(qos: .background).async {
                    dataFileManager.dataFileSave(accounts: accountsList.accounts) { result in
                        if case .failure(let error) = result {
                            fatalError(error.localizedDescription)
                        }
                    }
                }
            }
        }
        .onAppear {
            dataFileManager.dataFileLoad()  { result in
                switch result {
                case .failure(_):
                    fatalError("erreur dataFileManager")
                case .success(let accounts):
                    accountsList.accounts = accounts
                    
                    // Appeler la fonction pour initialiser grantTotalAccounts au lancement
                    self.calculGrantTotalAccounts()
                }
            }
        }
    }
    
    func calculGrantTotalAccounts() {
        let grantTotalAccounts = calculationsService.calculationOfGrantTotalOfAllAccountsAmounts(currentAccountsList: accountsList)
        self.grantTotalAccounts = grantTotalAccounts
    }
}



struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
