//
//  Calculation.swift
//  MonPorteMonnaie
//
//  Created by Adeline GIROIX on 11/09/2023.
//

import Foundation

struct CalculationsService {
    
    var format = "%.2f"
    
    // returns the initalAmount + currency icon of any current Account.
    func calculationOfAnAccountInitialAmount(currentAccount: Account) -> String {
        let initialAccount = " \(String(format: format, currentAccount.initialAmount)) \(currentAccount.currency.rawValue)"
        return initialAccount
    }
    
    // ### return the computered propertie Amount of an any Account (initialAmount + transactions).
    func calculationOfComputedPropertieAccountAmount(currentAccount: Account) -> Float {
        let amount = currentAccount.initialAmount + currentAccount.transactions.map { $0.amount }.reduce(0, +)
        return amount
    }
    
    // returns the amount propertie + currency icon of any current Account.
    func calculationTotalAmountOfOneAccount(currentAccount: Account) -> String {
        let totalAmountForOneAccount = "\(String(format: format, currentAccount.amount)) \(currentAccount.currency.rawValue)"
        return totalAmountForOneAccount
    }
    
    // ### return the grant total Amount of all Accouts Amounts in the AccountsList.
    func calculationOfGrantTotalOfAllAccountsAmounts(currentAccountsList: AccountsList) -> String {
        let grantTotalAllAccounts = "\(String(format: format, currentAccountsList.accounts.map {$0.amount}.reduce(0, +))) €"
        return grantTotalAllAccounts
    }
    
    // returns "Solde : " + amount + currency icon of any current Account.
    func calculationOfBalanceOfOneAccount(currentAccount: Account) -> String {
        let accountBalance = "Solde : \(String(format: format, currentAccount.amount)) \(currentAccount.currency.rawValue)"
        return accountBalance
    }
    
    // returns "Solde : " + amountEntered of a new Account created.
    func calculationOfNewAccountAmount(amountEntered: String) -> String {
        let newAmount = "Solde : \(String(format: format, Float(amountEntered) ?? 0)) €"
        return newAmount
    }
    
    
    // returns the Transaction Amount + currency icon of the current transaction in cell.
    func calculationOfTransactionAmount(currentTransaction: Transaction) -> String {
        let transactionAmount = "\(String(format: format, currentTransaction.amount)) \(currentTransaction.currency.rawValue)"
        return transactionAmount
    }
    
    // returns the Selected Account Amount + currency icon of the current index seclected account.
    func calculationOfAccountSelector(accountLlist: AccountsList, selectedAccountIndex: Int ) -> String {
        let selected = "(\(String(format: format,  accountLlist.accounts[selectedAccountIndex].amount)) \(accountLlist.accounts[selectedAccountIndex].currency.rawValue))"
        return selected
    }
        
    // returns the Selected Account Amount + currency icon of the current account.
    func calculationOfAccountSelectorAmount(currentAccount: Account) -> String {
        let AccountAmount = "(\(String(format: format, currentAccount.amount)) \(currentAccount.currency.rawValue))"
        return AccountAmount
    }
    
    // returns the integrity between the Account Amount done and the Account Amount recalculated
    func testSuccessIntegrityfullCalculationTotalOfOneAccount(currentAccount: Account) -> String {
        let temp = currentAccount.initialAmount + currentAccount.transactions.map { $0.amount }.reduce(0, +)
        let totalRecalculated = "\(String(format: format, temp)) \(currentAccount.currency.rawValue)"
        return String(totalRecalculated)
    }
}
