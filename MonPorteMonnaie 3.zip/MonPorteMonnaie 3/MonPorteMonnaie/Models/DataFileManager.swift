//
//  DataFileManager.swift
//  MonPorteMonnaie
//
//  Created by Adeline GIROIX on 18/09/2023.
//

import Foundation

struct DataFileManager {
    
    var accountsList = AccountsList()
    
    // generate the "FinanceTracker.data (text file)" URL.
    func dataFileURL() throws -> URL {
        let path = try FileManager.default.url(for: .documentDirectory,
                                               in: .userDomainMask,
                                               appropriateFor: nil,
                                               create: false)
        let url = path.appendingPathComponent("FinanceTracker.data")
        print(url)
        return url
    }
    
    
    // Proced to the loading of the persistant file accouts file
    func dataFileLoad(completion: @escaping (Result<[Account], Error>) -> Void) {
        DispatchQueue.global(qos: .background).async {
            do {
                let fileURL = try dataFileURL()
                
                guard let file = try? FileHandle(forReadingFrom: fileURL) else {
                    DispatchQueue.main.async {
                        completion(.success([]))
                    }
                    return
                }
                
                let accounts = try JSONDecoder().decode([Account].self, from: file.availableData)
                DispatchQueue.main.async {
                    completion(.success(accounts))
                }
            } catch {
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
            }
        }
    }
    
    
    func dataFileSave(accounts: [Account], completion: @escaping (Result<Int, Error>) -> Void) {
        DispatchQueue.global(qos: .background).async {
            do {
                let data = try JSONEncoder().encode(accounts)
                
                let outFile = try dataFileURL()
                
                try data.write(to: outFile)
                DispatchQueue.main.async {
                    completion(.success(accounts.count))
                }
            } catch {
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
            }
        }
    }
    
}


//A propos de dataFileSave et DispatchQueue est ce que la fonction ci-dessous est bien écrite ?
//
//func dataFileSave(accounts: [Account], completion: @escaping (Result<Int, Error>) -> Void) {
//        DispatchQueue.global(qos: .background).async {
//            do {
//                let data = try JSONEncoder().encode(accounts)
//
//                let outFile = try dataFileURL()
//
//                try data.write(to: outFile)
//                DispatchQueue.main.async {
//                    completion(.success(accounts.count))
//                }
//            } catch {
//                DispatchQueue.main.async {
//                    completion(.failure(error))
//                }
//            }
//        }
//    }
//ChatGPT
//La fonction dataFileSave semble bien écrite pour effectuer une sauvegarde asynchrone des comptes dans un fichier JSON en utilisant DispatchQueue. Cependant, voici une analyse plus détaillée :
//
//Utilisation de DispatchQueue : Vous utilisez DispatchQueue.global(qos: .background).async pour effectuer la sauvegarde dans un thread de fond, ce qui est une bonne pratique pour éviter de bloquer l'interface utilisateur pendant une opération de longue durée.
//
//Gestion des erreurs : Vous avez correctement encapsulé le code dans un bloc do-catch pour gérer les erreurs potentielles lors de l'encodage et de l'écriture des données. Les erreurs sont capturées et transmises à la closure de completion sous forme de .failure(error) en cas d'échec.
//
//Appel de completion : Lorsque la sauvegarde est réussie, vous appelez la closure completion avec .success(accounts.count), ce qui indique que la sauvegarde a réussi et transmet le nombre d'accounts sauvegardés. Assurez-vous que cela correspond à la logique de votre application.
//
//Gestion des threads : Vous utilisez DispatchQueue.main.async pour rappeler la closure completion sur le thread principal une fois que l'opération est terminée. Cela garantit que toute mise à jour de l'interface utilisateur liée à cette sauvegarde sera effectuée sur le thread principal, ce qui est généralement une bonne pratique.
//
//Dans l'ensemble, la fonction semble correctement écrite pour effectuer une sauvegarde asynchrone des comptes en prenant en charge la gestion des erreurs et en utilisant DispatchQueue pour la gestion des threads. Assurez-vous simplement que cela correspond à la logique et aux exigences spécifiques de votre application.
//
//
//
//
