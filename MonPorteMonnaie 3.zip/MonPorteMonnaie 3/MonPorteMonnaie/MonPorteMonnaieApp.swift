//
//  MonPorteMonnaieApp.swift
//  MonPorteMonnaie
//
//  Created by Adeline GIROIX on 19/07/2023.
//

import SwiftUI

@main
/// Structure principale de l'application et est utilisée pour définir l'entrée de l'application.
/// Main structure of the application and is used to define the application input.
struct MonPorteMonnaieApp: App {
    var body: some Scene {
        WindowGroup {
            HomeView()
        }
    }
}
