//
//  MonPorteMonnaieApp.swift
//  MonPorteMonnaie
//
//  Created by Adeline GIROIX on 19/07/2023.
//

import SwiftUI

@main
struct MonPorteMonnaieApp: App {
    var body: some Scene {
        WindowGroup {
            HomeView()
        }
    }
}
