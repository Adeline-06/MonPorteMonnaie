//
//  TransactionCell.swift
//  MonPorteMonnaie
//
//  Created by Adeline GIROIX on 08/08/2023.
//

import SwiftUI

struct TransactionCell: View {
    
    let accountsList = AccountsList()
    let calculation = CalculationsService()
    let dataFileManager = DataFileManager()
    
    @ObservedObject var transaction: Transaction
    let onDelete: () -> Void
    @State private var isDetailedMode = false
    @State private var isEditingMode = false
    @State private var tempLabel: String = ""
    @FocusState private var focusedField: Field?
    
    let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy à HH:mm"
        return formatter
    }()
    
    var body: some View {
        VStack(spacing: 16) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    if isEditingMode {
                        TextField("Ex : Frais divers...", text: $tempLabel)
                                .font(.headline)
                                .focused($focusedField, equals: .label)
                                .onChange(of: tempLabel) { newName in
                                    // La valeur du TextField a été modifiée, déclenchez la sauvegarde
                                    transaction.label = newName // Mettez à jour la valeur réelle de la transaction
                                    saveDataFile()
                                }
                    } else {
                        Text(transaction.label)
                            .font(.headline)
                    }
                    Text(dateFormatter.string(from: transaction.date))
                        .font(.footnote)
                        .foregroundColor(Color(white: 0.4))
                }
                Spacer()
                Text(calculation.calculationOfTransactionAmount(currentTransaction: transaction))
                    .foregroundColor(transaction.amount >= 0.00 ? .green : Color(.red))
                    .font(.title3)
                    .foregroundColor(Color(white: 0.4))
            }
            if isDetailedMode {
                VStack {
                    Button {
                        isEditingMode = true
                        focusedField = .label
                    } label: {
                        Label("Renommer cette transaction", systemImage: "pencil")
                    }
                    .foregroundColor(Color.blue)
                }
                VStack {
                    Button(role: .destructive) {
                        onDelete()
                    } label: {
                        Label("Suppimer cette transaction", systemImage: "trash")
                    }
                    .foregroundColor(.red)
                    .frame(maxWidth: .infinity)
                }
                .environmentObject(accountsList)
                }
            }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(Color.white)
        .cornerRadius(16)
        .onTapGesture {
            withAnimation {
                isDetailedMode.toggle()
            }
        }
    }
    
    
    
    func saveDataFile() {
        dataFileManager.dataFileSave(accounts: accountsList.accounts) { result in
            if case .failure(let error) = result {
                fatalError(error.localizedDescription)
            }
        }
    }
    
    
    private enum Field:Int, Hashable {
        case label
    }
}

struct TransactionCell_Previews: PreviewProvider {
    static var previews: some View {
        TransactionCell(transaction: previewTransactions[0], onDelete: {})
            .padding(24)
            .background(Color("grey"))
            .previewLayout(.sizeThatFits)
    }
}

//L'erreur que vous rencontrez est due au fait que la méthode onChange(of:perform:) de SwiftUI nécessite que la valeur passée en premier argument (dans ce cas $transaction.label) soit conforme au protocole Equatable. Les Binding de type String, tels que $transaction.label, ne sont pas conformes à Equatable par défaut, c'est pourquoi vous obtenez cette erreur.
//
//Pour résoudre ce problème, vous pouvez utiliser une approche alternative en utilisant une variable de stockage temporaire pour le texte du TextField et en comparant cette variable avec la nouvelle valeur pour déclencher la sauvegarde. Voici comment vous pourriez le faire :
//
//swift
//Copy code
//@State private var tempLabel: String = ""
//
//// ...
//
//if isEditingMode {
//    TextField("Ex : Frais divers...", text: $tempLabel)
//        .font(.headline)
//        .focused($focusedField, equals: .label)
//        .onChange(of: tempLabel) { newName in
//            // La valeur du TextField a été modifiée, déclenchez la sauvegarde
//            transaction.label = newName // Mettez à jour la valeur réelle de la transaction
//            saveDataFile()
//        }
//}
//Dans cet exemple, nous utilisons @State private var tempLabel: String = "" pour stocker temporairement la valeur du TextField. Lorsque le TextField est modifié, nous mettons à jour la valeur réelle de la transaction (transaction.label) avec la nouvelle valeur du tempLabel, puis nous appelons saveDataFile() pour déclencher la sauvegarde des données.
//
//Cela permet d'éviter l'erreur liée à l'équatabilité des Binding de type String.
