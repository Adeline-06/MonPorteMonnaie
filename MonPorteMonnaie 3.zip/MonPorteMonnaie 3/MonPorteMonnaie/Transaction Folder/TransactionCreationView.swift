//
//  NewTransactionView.swift
//  MonPorteMonnaie
//
//  Created by Adeline GIROIX on 16/08/2023.
//

import SwiftUI

struct TransactionCreationView: View {
    
    var completionHandler: ((Bool) -> Void)? // Définition de la closure de complétion
    
    let calculationsService = CalculationsService()
    let dataFileManager = DataFileManager()
    
    @Environment(\.presentationMode) var presentationMode
    
    @EnvironmentObject var accountsList: AccountsList
    
    @State private var selectedAccountIndex = 0
    @State private var textFieldAmount = ""
    @State private var transactionName = ""
    @State private var transactionDate = Date()
    @State private var isPresentingNewAccountScreen = false
        
    var body: some View {
        VStack(spacing: 32) {
            Text("Nouvelle Transaction")
                .font(.system(size: 32, weight: .bold))
                .padding(.top, 32)
//            HStack {
//                TextField("0.00", text: $textFieldAmount)
//                    .keyboardType(.numbersAndPunctuation)
//                    .submitLabel(.done)
//                    .foregroundColor(Color.black.opacity(1.4))
//                    .font(.system(size: 48, weight: .semibold))
//                    .frame(width: nil, height: nil, alignment: .trailing)
//                    .multilineTextAlignment(.center)
//                Text(accountsList.accounts[selectedAccountIndex].currency.rawValue)
//                    .font(.system(size: 24, weight: .light))
//            }
//            Text("Sélectionner un compte :")
//                .font(.system(size: 24, weight: .bold))
//                .padding(.top, 16)
            VStack(spacing: 16) {
                AccountSelectorMenu(accountList: accountsList, selectedAccountIndex: $selectedAccountIndex) {
                    isPresentingNewAccountScreen = true
                }
//                AccountSelectorMenu(accountList: accountsList, selectedAccountIndex: $selectedAccountIndex) {
//                    isPresentingNewAccountScreen = true
//                }
                            HStack {
                                HStack {
                                    Text(accountsList.accounts[selectedAccountIndex].name)
                                    Text(String(accountsList.accounts[selectedAccountIndex].amount))
                                }
                                .padding(12)
                                .padding(.horizontal, 12)
                                .foregroundColor(accountsList.accounts[selectedAccountIndex].amount >= 0.00 ? .green : Color(.red))
                            }
                            .cornerRadius(12) // Coins arrondis
                            .frame(maxWidth: .infinity) // Pour centrer horizontalement
                            .border(Color.blue, width: 2) // Ajoute une bordure bleue de 2 points d'épaisseur au bouton
                            .font(.title)
                            .bold()
                            .background(Color("pink"))
                            .foregroundColor(.white)
                            .border(Color.blue, width: 2) // Bordure
                TextField("Ex : Loyer...", text: $transactionName)
                    .submitLabel(.done)
                    .padding(12)
                    .padding(.horizontal, 12)
                    .background(Color.white)
                    .cornerRadius(.infinity)
                DatePicker("Date : ", selection: $transactionDate)
                    .padding(.leading, 24)
                    .padding(.trailing, 8)
            }
            HStack {
                TextField("0.00", text: $textFieldAmount)
                    .keyboardType(.numbersAndPunctuation)
                    .submitLabel(.done)
                    .foregroundColor(Color.black.opacity(1.4))
                    .font(.system(size: 48, weight: .semibold))
                    .frame(width: nil, height: nil, alignment: .trailing)
                    .multilineTextAlignment(.center)
                Text(accountsList.accounts[selectedAccountIndex].currency.rawValue)
                    .font(.system(size: 24, weight: .light))
            }
            Spacer()
            MainButton(title: "Ajouter") {
                
                let newTransaction = Transaction(
                    label: transactionName,
                    amount: Float(textFieldAmount) ?? 0.0,
                    currency: accountsList.accounts[selectedAccountIndex].currency,
                    date: transactionDate
                )
                // Ajout de la transaction au compte
                accountsList.accounts[selectedAccountIndex].transactions.append(newTransaction)
                
//                DispatchQueue.global(qos: .background).async {
//                    dataFileManager.dataFileSave(accounts: accountsList.accounts) { result in
//                        if case .failure(let error) = result {
//                            fatalError(error.localizedDescription)
//                        }
//                    }
//                }
                DispatchQueue.global(qos: .background).async {
                                dataFileManager.dataFileSave(accounts: accountsList.accounts) { result in
                                    if case .failure(let error) = result {
                                        fatalError(error.localizedDescription)
//                                        completionHandler?(false) // Appel de la closure en cas d'échec
                                    } else {
                                        completionHandler?(true) // Appel de la closure en cas de succès
                                    }
                                }
                            }
                
                presentationMode.wrappedValue.dismiss()
            }
            
        }
        .padding()
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
        .background(Color("grey"))
        .sheet(isPresented: $isPresentingNewAccountScreen) {
            AccountCreationView { newAccount in
                accountsList.accounts.append(newAccount)
            }
        }
    }
}

//struct NewTransactionView_Previews: PreviewProvider {
//    static var previews: some View {
//        TransactionCreationView(dataModel: dataModel)
//    }
//}
