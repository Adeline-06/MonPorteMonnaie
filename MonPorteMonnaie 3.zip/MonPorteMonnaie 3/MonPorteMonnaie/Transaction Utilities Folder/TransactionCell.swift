//
//  TransactionCell.swift
//  MonPorteMonnaie
//
//  Created by Adeline GIROIX on 08/08/2023.
//

import SwiftUI

struct TransactionCell: View {
    
    let accountsList = AccountsList()
    let calculation = CalculationsService()
    let dataFileManager = DataFileManager()
    
    @ObservedObject var transaction: Transaction
    let onDelete: () -> Void
    @State private var isDetailedMode = false
    @State private var isEditingMode = false
    @State private var tempLabel: String = ""
    @FocusState private var focusedField: Field?
    
    let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy à HH:mm"
        return formatter
    }()
    
    var body: some View {
        VStack(spacing: 16) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    if isEditingMode {
                        TextField("Ex : Frais divers...", text: $tempLabel)
                                .font(.headline)
                                .focused($focusedField, equals: .label)
                                .onChange(of: tempLabel) { newName in
                                    // La valeur du TextField a été modifiée, déclenchez la sauvegarde
                                    transaction.label = newName // Mettez à jour la valeur réelle de la transaction
                                    saveDataFile()
                                }
                    } else {
                        Text(transaction.label)
                            .font(.headline)
                    }
                    Text(dateFormatter.string(from: transaction.date))
                        .font(.footnote)
                        .foregroundColor(Color(white: 0.4))
                }
                Spacer()
                Text(calculation.calculationOfTransactionAmount(currentTransaction: transaction))
                    .font(.system(size: 24, weight: .bold))
                    .foregroundColor(foregroundColorText(transaction.amount))
//                    .foregroundColor(Color(white: 0.4))
            }
            if isDetailedMode {
                VStack {
                    Button {
                        isEditingMode = true
                        focusedField = .label
                    } label: {
                        Label("Renommer cette transaction", systemImage: "pencil")
                    }
                    .foregroundColor(Color.blue)
                }
                VStack {
                    Button(role: .destructive) {
                        onDelete()
                    } label: {
                        Label("Suppimer cette transaction", systemImage: "trash")
                    }
                    .foregroundColor(.red)
                    .frame(maxWidth: .infinity)
                }
                .environmentObject(accountsList)
                }
            }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(Color.white)
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(Color.blue, lineWidth: 1)
        )
        .onTapGesture {
            withAnimation {
                isDetailedMode.toggle()
            }
        }
    }
    
    
    
    func saveDataFile() {
        dataFileManager.dataFileSave(accounts: accountsList.accounts) { result in
            if case .failure(let error) = result {
                fatalError(error.localizedDescription)
            }
        }
    }
    
    
    private enum Field:Int, Hashable {
        case label
    }
    
    
    func foregroundColorText(_ value: Float) -> Color {
        if value == 0 {
            return .black
        } else if value == 0 {
            return .black
        } else if value > 0 {
            return .green
        } else {
            return Color(.red)
        }
    }
}
