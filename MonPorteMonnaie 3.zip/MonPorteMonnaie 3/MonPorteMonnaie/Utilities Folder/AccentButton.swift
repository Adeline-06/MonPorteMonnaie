//
//  AccentButton.swift
//  MonPorteMonnaie
//
//  Created by Adeline GIROIX on 08/08/2023.
//

import SwiftUI

struct AccentButton: View {
    
    let title: String
    let color: Color
    let action: () -> Void
    
    var body: some View {
        Button(action: action){
            Text(title)
                .foregroundColor(.black)
                .font(.system(size: 20))
                .fontWeight(.semibold)
                .frame(maxWidth: .infinity)
                .padding(8)
            //                .background(color)
                .background(RoundedRectangle(cornerRadius: 10).fill(color)
                )
            
            
        }
    }
}

struct AccentButton_Previews: PreviewProvider {
    static var previews: some View {
        AccentButton(title: "Test Button", color: Color("orange"), action: {})
            .padding()
            .previewLayout(.sizeThatFits)
    }
}
