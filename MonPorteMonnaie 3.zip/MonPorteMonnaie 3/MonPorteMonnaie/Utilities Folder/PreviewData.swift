//
//  PreviewData.swift
//  MonPorteMonnaie
//
//  Created by Adeline GIROIX on 01/08/2023.
//

import Foundation

let previewAccounts: [Account] = [
    Account(iconName: "icon_001", name: "Visa", initialAmount: 11.11,
            transactions: previewTransactions, currency: .euro),
    Account(iconName: "icon_002", name: "Paypal", initialAmount: 222.22,
            transactions: previewTransactions, currency: .euro),
    Account(iconName: "icon_003", name: "Perso", initialAmount: 3333.33,
            transactions: previewTransactions, currency: .euro)
]

let previewTransactions = [
    Transaction(label: "Repas", amount: 12.25, currency: .euro, date: Date()),
    Transaction(label: "Métro", amount: 18.50, currency: .euro, date: Date()),
    Transaction(label: "Loyer", amount: 745, currency: .euro, date: Date())
]
