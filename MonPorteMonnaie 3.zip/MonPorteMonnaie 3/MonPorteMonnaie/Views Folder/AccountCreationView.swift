//
//  AccountCreationView.swift
//  MonPorteMonnaie
//
//  Created by Adeline GIROIX on 06/08/2023.
//

import SwiftUI

///  Cette structure sert à créer un nouvel objet Account en permettant à l'utilisateur de saisir des informations telles que le nom, l'icône, le solde initial et la devise.
///  /// This structure is used to create a new Account object by allowing the user to enter information such as name, icon, initial balance and currency.
struct AccountCreationView: View {
    
    let calculationsService = CalculationsService()
    
    /// Cette propriété permet de gérer le mode de présentation de la vue, notamment pour la fermer après la création d'un compte.
    /// This property allows you to manage the presentation mode of the view, in particular to close it after creating an account.
    @Environment(\.presentationMode) var presentationMode
    
    @State private var accountName: String = ""
    @State private var amount = ""
    @State private var selectedCurrency: Currency = .euro
    @State private var selectedIcon: String = ""
    //    @State private var isShowingNoNameAccountAlert = false
    
    @State private var alert: AlertData? // Créez une variable d'état pour stocker l'alerte
    
    var onAccountCreated: (Account) -> Void
    
    var body: some View {
        VStack(spacing: 32) {
            VStack(spacing: 16) {
                Text(accountName == "" ? "Nouveau Compte" : accountName)
                    .padding()
                    .frame(maxWidth: .infinity) // Pour centrer horizontalement
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.blue, lineWidth: 1)
                    )
                    .font(.system(size: 20, weight: .semibold))
                    .background(Color("purple"))
                    .foregroundColor(.black)
                Text(calculationsService.calculationOfNewAccountAmount(amountEntered: amount))
                    .font(.system(size: 20, weight: .bold))
                    .foregroundColor(foregroundColorText(amount))
                    .padding(.top, 12)
                
            }
            VStack(alignment: .leading) {
                Text("Nom :")
                    .font(.system(size: 20, weight: .bold))
                    .padding(.top, 6)
                    .padding(.bottom, 12)
                TextField("Ex : Paypal...", text: $accountName)
                    .submitLabel(.done)
                    .padding(12)
                    .padding(.horizontal, 12)
                    .background(Color.white)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.blue, lineWidth: 1)
                    )
            }
            .padding(.bottom, 20)
            VStack(alignment: .leading) {
                Text("Icone")
                    .font(.system(size: 20, weight: .bold))
                    .padding(.bottom, 12)
                AccountSelectedIcon(selectedIcon: $selectedIcon)
                    .padding()
                    .padding(.horizontal, -2)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.blue, lineWidth: 1)
                    )
                    .background(.white)
            }
            .padding(.bottom, 14)
            VStack(alignment: .leading) {
                Text("Solde Initial")
                    .font(.system(size: 20, weight: .bold))
                    .padding(.top, 12)
                    .padding(.bottom, 12)
                HStack {
                    TextField("Ex : 123,45 \(selectedCurrency.rawValue)", text: $amount)
                        .padding(12)
                        .padding(.horizontal, 12)
                        .keyboardType(.numbersAndPunctuation)
                        .submitLabel(.done)
                    CurrencySelector(selectedCurrency: $selectedCurrency)
                        .foregroundColor(Color(.darkGray))
                        .padding()
                }
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(Color.blue, lineWidth: 1)
                )
                .background(Color.white)
            }
            .padding(.bottom,20)
            
            
            
            
            
            MainButton(title: "Ajouter") {
                
                var counter = 0
                var alertMessage = ""
                
                if accountName.isEmpty {
                    counter += 1
                    alertMessage += "\n\(counter) - Nommer ce compte!\n"
                }
                if selectedIcon == "" {
                    counter += 1
                    alertMessage += "\n\(counter) - Choisir une icône pour ce compte!\n"
                }
                
                if amount == "" || Float(amount) == 0 {
                    counter += 1
                    alertMessage += "\n\(counter) - Saisir un montant ionitial!\n"
                }
                
                
                // EASTER EGGS pour rigoler :-)))
                if counter != 0 {
                    counter += 1
                    alertMessage += "\nEt \(counter) - Faire le café! Merci!\n"
                }
                
                
                if !alertMessage.isEmpty {
                    // Affichez l'alerte en définissant la variable alert
                    alert = AlertData(title: "Attention !", message: alertMessage)
                } else {
                    let newAccount = Account(
                        iconName: selectedIcon,
                        name: accountName,
                        initialAmount: Float(amount) ?? 0,
                        transactions: [],
                        currency: selectedCurrency
                    )
                    onAccountCreated(newAccount)
                    presentationMode.wrappedValue.dismiss()
                }
            }
            // Utilisez l'alerte en fonction de l'état de la variable alert
            .alert(item: $alert) { alertData in
                Alert(
                    title: Text(alertData.title),
                    message: Text(alertData.message),
                    primaryButton: .destructive(Text("OK"), action: {
                    }), secondaryButton: .cancel(Text("Annuler"))
                )
            }
        }
        .padding()
        .background(Color("grey"))
    }
    
    
    func foregroundColorText(_ value: String) -> Color {
        if value == "" {
            return .black
        } else if Float(value) ?? 0 == 0 {
            return .black
        } else if Float(value) ?? 0 > 0 {
            return .green
        } else {
            return Color(.red)
        }
    }
    
}
