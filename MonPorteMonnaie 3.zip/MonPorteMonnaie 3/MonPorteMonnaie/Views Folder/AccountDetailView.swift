//
//  AccountDetailView.swift
//  MonPorteMonnaie
//
//  Created by Adeline GIROIX on 09/08/2023.
//

import SwiftUI

struct AccountDetailView: View {
    
    let calculation = CalculationsService()
    let dataFileManager = DataFileManager()
    
    @EnvironmentObject var accountsList: AccountsList
    @Environment(\.presentationMode) var presentationMode
    @ObservedObject var account: Account
    @State private var isShowingAccountDeletionAlert = false
    @State private var isShowingTransactionAlert = false
    @State private var selectedTransactionToDelete: Transaction? = nil
    @State private var isEditingMode = false
    @FocusState private var focusedField: Field?
    
    @Binding var grantTotalAccounts: String // Ajoutez une liaison pour grantTotalAccounts
    
    var onCompletion: ((Bool) -> Void)?
    
    var body: some View {
        
        
        ScrollView {
            VStack {
                Button {
                    isEditingMode = true
                    focusedField = .name
                } label: {
                    Label("Renommer ce compte", systemImage: "pencil")
                        .foregroundColor(Color.blue)
                }
                .padding(.bottom, 2)
                Button(role: .destructive) {
                    isShowingAccountDeletionAlert = true
                } label: {
                    Label("Supprimer ce compte", systemImage: "trash")
                }
            }
            .padding()
            .font(.system(size: 18, weight: .bold))
            
            .alert(isPresented: $isShowingAccountDeletionAlert) {
                Alert(
                    title: Text("Attention !"),
                    message: Text("Le compte va être supprimé\nToutes les transactions liées seront perdues."),
                    
                    primaryButton: .destructive(
                        Text("Supprimer")
                            .bold() // Applique un style de texte en gras
                            .foregroundColor(.red), // Change la couleur du texte en rouge
                        action: {
                            // D'abord, supprimez le compte
                            accountsList.accounts.removeAll { element in
                                element.id == account.id
                            }
                        
                        // data saving
                        dataFileManager.dataFileSave(accounts: accountsList.accounts) { result in
                            if case .failure(let error) = result {
                                fatalError(error.localizedDescription)
                            } else {
                                // Indiquez le succès de l'opération en appelant la complétion
                                onCompletion?(true)
                                // Mettez à jour grantTotalAccounts avec la nouvelle valeur
                                grantTotalAccounts = calculation.calculationOfGrantTotalOfAllAccountsAmounts(currentAccountsList: accountsList)
                            }
                        }
                        
                        // Enfin, revenez à l'écran précédent
                        withAnimation {
                            presentationMode.wrappedValue.dismiss()
                        }
                    }),
                    secondaryButton: .cancel(Text("Annuler"))
                )
            }
            VStack(spacing: 24) {
                HStack {
                    if isEditingMode {
                        TextField("Entrer un nom....", text: $account.name)
                            .font(.system(size: 32, weight: .bold))
                            .focused($focusedField, equals: .name)
                            .onChange(of: account.name) { newName in
                                // La valeur du TextField a été modifiée, déclenchez la sauvegarde
                                saveDataFile()
                            }
                    } else {
                        Text(account.name)
                            .font(.system(size: 32, weight: .bold))
                    }
                    Spacer()
                    Text(calculation.calculationTotalAmountOfOneAccount(currentAccount: account))
                        .font(.system(size: 32, weight: .bold))
                }
                .padding()
                .cornerRadius(12) // Coins arrondis
                .frame(maxWidth: .infinity) // Pour centrer horizontalement
                .border(Color.blue, width: 2) // Ajoute une bordure bleue de 2 points d'épaisseur au bouton
                .foregroundColor(foregroundColorText(account.amount))
                .background(Color("purple"))
                .border(Color.blue, width: 2) // Bordure
                Divider()
                VStack(spacing: 16) {
                    if account.transactions.isEmpty {
                        Text("Aucune transaction enregistrée ...")
                            .font(.callout)
                            .foregroundColor(Color(white: 0.4))
                    }
                    ForEach(account.transactions) { transaction in
                        TransactionCell(transaction: transaction, onDelete: {
                            isShowingTransactionAlert = true
                            selectedTransactionToDelete = transaction
                        })
                    }
                    HStack {
                        Text("Solde initial :")
                            .font(.system(size: 24, weight: .bold))
                            .foregroundColor(foregroundColorText(account.amount))
                        Text(calculation.calculationOfAnAccountInitialAmount(currentAccount: account))
                            .font(.system(size: 24, weight: .bold))
                            .foregroundColor(foregroundColorText(account.amount))
                    }
                    .foregroundColor(Color(white: 0.5))
                    .padding()
                }
                
                .alert(isPresented: $isShowingTransactionAlert) {
                    Alert(
                        title: Text("Attention !"),
                        message: Text("\nSuppression de la transaction\n\nCette action sera irréversible\n"),
                        primaryButton: .destructive(Text("Supprimer"), action: {
                            // Supprimez la transaction
                            withAnimation {
                                account.transactions.removeAll { transaction in
                                    selectedTransactionToDelete!.id == transaction.id
                                }
                            }
                            selectedTransactionToDelete = nil
                            
                            // Utilisez DispatchQueue pour effectuer la sauvegarde des données de manière asynchrone
                            DispatchQueue.global(qos: .background).async {
                                dataFileManager.dataFileSave(accounts: accountsList.accounts) { result in
                                    if case .failure(let error) = result {
                                        fatalError(error.localizedDescription)
                                    } else {
                                        // Indiquez le succès de l'opération en appelant la complétion
                                        onCompletion?(true)
                                        // Mettez à jour grantTotalAccounts avec la nouvelle valeur
                                        grantTotalAccounts = calculation.calculationOfGrantTotalOfAllAccountsAmounts(currentAccountsList: accountsList)
                                    }
                                }
                            }
                        }),
                        secondaryButton: .cancel(Text("Annuler"))
                    )
                }
            }
            .padding()
            .navigationBarBackButtonHidden(true)
            .navigationBarItems(leading:
                Button(action: {
                    // Code à exécuter lorsque le bouton de retour est cliqué
                    presentationMode.wrappedValue.dismiss() // Pour revenir en arrière
                }) {
                    HStack {
                        Image(systemName: "arrow.left.circle.fill")
                            .font(.system(size: 20, weight: .bold))
                        Text("Retour à la Liste des Comptes")
                            .padding(.top, 20)
                            .padding(.leading, 2)
                            .padding(.bottom, 12)
                            .italic()
                            .foregroundColor(Color.black.opacity(0.5))
                            .font(.system(size: 20, weight: .bold))
                        
                    }
                }
            )
        }
        .background(Color("grey"))
    }
    
    func saveDataFile() {
        dataFileManager.dataFileSave(accounts: accountsList.accounts) { result in
            if case .failure(let error) = result {
                fatalError(error.localizedDescription)
            }
        }
    }
    
    private enum Field: Int, Hashable {
        case name
    }
    
    func foregroundColorText(_ value: Float) -> Color {
        if value == 0 {
            return .black
        } else if value == 0 {
            return .black
        } else if value > 0 {
            return .green
        } else {
            return Color(.red)
        }
    }
    
}
