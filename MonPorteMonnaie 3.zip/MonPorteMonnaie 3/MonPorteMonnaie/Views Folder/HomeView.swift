//
//  HomeView.swift
//  MonPorteMonnaie
//
//  Created by Adeline GIROIX on 19/07/2023.
//

import SwiftUI

/// Définit une structure SwiftUI appelée HomeView, qui représente la vue principale de l'application.
/// This defines a SwiftUI structure called HomeView, which represents the main view of the application
struct HomeView: View {
    
    /// Une instance de CalculationsService est créée pour effectuer des calculs dans l'application.
    /// An instance of CalculationsService is created to perform calculations in the application
    let calculationsService = CalculationsService()
    /// Une instance de DataFileManager est créée pour gérer la gestion des données(la sauvegarde,chargement des comptes, transactions)
    /// Manage data management, probably saving and loading accounts and transactions.
    let dataFileManager = DataFileManager()
    
    @Environment(\.scenePhase) private var scenePhase
    
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    
    @State private var isPresentingNewAccountScreen = false
    @State private var isPresentingNewTransactionScreen = false
    @State private var isShowingFavouritesOnly = false
    @State private var isShowingNoAccountAlert = false
    
    /// Sert à stocker la liste des comptes, ce qui signifie que la vue sera automatiquement actualisée lorsqu'elle change.
    /// @StateObject to store the list of accounts, which means the view will automatically refresh when it changes.
    @StateObject var accountsList = AccountsList()
    
    /// Une propriété @State pour stocker le total des comptes, probablement utilisée pour afficher le solde global à l'utilisateur.
    /// Stock total accounts, shows overall balance
    @State private var grantTotalAccounts = ""
    
    /// Le corps principal de la vue, definissant sa mise en page et son contenu
    /// The main body of the view, defining its layout and content.
    var body: some View {
        NavigationView {
            ScrollView {
                VStack {
                    Button(action: {
                        // Code pour quitter l'application
                        UIControl().sendAction(#selector(NSXPCConnection.suspend), to: UIApplication.shared, for: nil)
                    }) {
                        HStack() {
                            Text("Accueil Mes Comptes")
                                .italic()
                                .multilineTextAlignment(.trailing)
                                .font(.system(size: 24, weight: .bold))
                                .foregroundColor(Color.black.opacity(0.5))
                            Spacer()
                            Text("Quitter")
                            Image(systemName: "power")
                                .multilineTextAlignment(.trailing)
                        }
                        .padding()
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(.red)
                    }
                }
                VStack(spacing: 8) {
                    Text("Solde global en cours:")
                        .font(.system(size: 16, weight: .medium))
                    Text(grantTotalAccounts)
                        .font(.system(size: 20, weight: .bold))
                        .foregroundColor(foregroundColorText(grantTotalAccounts))
                }
                .padding(.horizontal, 16)
                VStack {
                    HStack(spacing: 16) {
                        AccentButton(title: "Comptes", color: Color("orange")) {
                            isPresentingNewAccountScreen = true
                        }
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.blue, lineWidth: 1)
                        )
                        .foregroundColor(.black)
                        .font(.system(size: 16, weight: .light))
                        .opacity(0.8)
                        AccentButton(title: "Transactions", color: Color("cian")) {
                            if accountsList.accounts.isEmpty {
                                isShowingNoAccountAlert = true
                            } else {
                                isPresentingNewTransactionScreen = true
                            }
                        }
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.blue, lineWidth: 1)
                        )
                        .foregroundColor(.black)
                        .font(.system(size: 16, weight: .light))
                        .opacity(0.8)
                    }
                    .frame(maxWidth: .infinity, alignment: .center)
                    .padding(.bottom, 10)
                    VStack() {
                        HStack {
                            Text("Mes Comptes")
                                .padding()
                            Button {
                                withAnimation {
                                    isShowingFavouritesOnly.toggle()
                                }
                            } label: {
                                Image(systemName: isShowingFavouritesOnly ? "star.fill" : "star")
                                    .resizable()
                                    .foregroundColor(isShowingFavouritesOnly ? .yellow : Color(white: 0.2))
                                    .frame(width: 30, height: 30)
                            }
                        }
                        .padding(.horizontal, 12)
                        .background(Color("purple"))
                        .foregroundColor(.black)
                        .opacity(0.8)
                        .font(.system(size: 20, weight: .bold))
                    }
                    .padding(10)
                    .border(Color.blue, width: 1) // Ajoute une bordure bleue de 2 points d'épaisseur
                    .frame(maxWidth: .infinity, alignment: .center)
                    if accountsList.accounts.count > 0 {
                        VStack (spacing: 16) {
                            /// Une boucle de vue pour afficher chaque compte dans la liste.
                            /// A view loop to display each account in the list.
                            ForEach(accountsList.accounts) { account in
                                if !isShowingFavouritesOnly || account.isFavourite {
                                    NavigationLink {
                                        withAnimation {
                                            AccountDetailView(account: account, grantTotalAccounts: $grantTotalAccounts) { success in
                                                if success {
                                                    /// Gestion de la complétion en cas de succès
                                                    /// Management of completion in case of success

                                                } else {
                                                    /// Gestion de la complétion en cas d'échec
                                                    /// Management of completion in case of failure
                                                }
                                            }
                                            .environmentObject(accountsList)
                                        }
                                    } label: {
                                        AccountCell(account: account)
                                    }
                                }
                            }
                        }
                        .padding(.top, 12)
                        .frame(maxWidth: .infinity, alignment: .center)
                    } else {
                        Text("Pas de compte enregistré...")
                            .padding(32)
                    }
                }
                .padding(.horizontal, 26)
                .frame(maxWidth: .infinity, alignment: .center)
            }
            .background(Color("grey"))
            .sheet(isPresented: $isPresentingNewAccountScreen) {
                AccountCreationView() { newAccount in
                    accountsList.accounts.append(newAccount)
                    
                    self.calculGrantTotalAccounts()
                    
                    dataFileManager.dataFileSave(accounts: accountsList.accounts) { result in
                        if case .failure(let error) = result {
                            fatalError(error.localizedDescription)
                        }
                    }
                }
            }
            /// Affiche une alerte si aucun compte n'est présent.
            /// Shows an alert if no account is present.
            .alert(isPresented: $isShowingNoAccountAlert) {
                Alert(
                    title: Text("Attention !"),
                    message: Text("Aucun compte existant pour pouvoir associer des transactions..."),
                    primaryButton: .default(Text("Créer un compte"), action: {
                        isPresentingNewAccountScreen = true
                    }), secondaryButton: .default(Text("Annuler")))
            }
            .sheet(isPresented: $isPresentingNewTransactionScreen) {
                TransactionCreationView { success in
                    if success {
                        self.calculGrantTotalAccounts()
                    } else {
                        // ...
                    }
                }
                .environmentObject(accountsList)
            }
        }
        ///Exécute une action lorsque la phase de scène change, par exemple, pour sauvegarder les données lorsque l'application passe en arrière-plan.
        ///Performs an action when the scene phase changes, for example, to save data when the application goes into the background.
        .onChange(of: scenePhase) { phase in
            if phase == .inactive {
                DispatchQueue.global(qos: .background).async {
                    dataFileManager.dataFileSave(accounts: accountsList.accounts) { result in
                        if case .failure(let error) = result {
                            fatalError(error.localizedDescription)
                        }
                    }
                }
            }
        }
        ///Exécute une action lorsque la vue apparaît pour la première fois, probablement pour charger les données initiales.
        ///Performs an action when the view first appears, probably to load initial data.
        .onAppear {
            dataFileManager.dataFileLoad()  { result in
                switch result {
                case .failure(_):
                    fatalError("erreur dataFileManager")
                case .success(let accounts):
                    accountsList.accounts = accounts
                    
                    ///Appeler la fonction pour initialiser grantTotalAccounts au lancement
                    /// Call the function to initialize grand Total Accounts at launch
                    self.calculGrantTotalAccounts()
                }
            }
        }
    }
    
    /// Fonction pour calculer le total des comptes.
    /// Function to calculate the total of accounts
    func calculGrantTotalAccounts() {
        let grantTotalAccounts = calculationsService.calculationOfGrantTotalOfAllAccountsAmounts(currentAccountsList: accountsList)
        self.grantTotalAccounts = grantTotalAccounts
    }
    
    
    func foregroundColorText(_ value: String) -> Color {
        if value == "0.00 €" {
            return .black
        } else if value >= "0.00" {
            return .green
        } else {
            return Color(.red)
        }
    }
    
}

