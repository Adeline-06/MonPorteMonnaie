//
//  NewTransactionView.swift
//  MonPorteMonnaie
//
//  Created by Adeline GIROIX on 16/08/2023.
//

import SwiftUI


struct TransactionCreationView: View {
    
    var completionHandler: ((Bool) -> Void)? // Définition de la closure de complétion
    
    let calculationsService = CalculationsService()
    let dataFileManager = DataFileManager()
    
    @Environment(\.presentationMode) var presentationMode
    
    @EnvironmentObject var accountsList: AccountsList
    
    @State private var selectedAccountIndex = -1
    @State private var textFieldAmount = ""
    @State private var transactionName = ""
    @State private var transactionDate = Date()
    @State private var isPresentingNewAccountScreen = false
    
//    @State private var alertMessage = "" // Assurez-vous que alertMessage est @State
//    @State private var isShowingAlert = false
    
    @State private var alert: AlertData? // Créez une variable d'état pour stocker l'alerte


    var body: some View {
        
        VStack(spacing: 32) {
            Text("Nouvelle Transaction")
                .padding()
            //                .padding(.leading,  26)
                .multilineTextAlignment(.center)
                .font(.system(size: 32, weight: .bold))
                .frame(maxWidth: .infinity) // Pour centrer horizontalement
                .background(Color("cian"))
                .foregroundColor(.black)
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(Color.blue, lineWidth: 1)
                )
            VStack(spacing: 16) {
                AccountSelectorMenu(accountList: accountsList, selectedAccountIndex: $selectedAccountIndex) {
                    isPresentingNewAccountScreen = true
                }
                HStack {
                    if selectedAccountIndex > -1 {
                        HStack {
                            Text(accountsList.accounts[selectedAccountIndex].name)
                                .font(.system(size: 24, weight: .bold))
                                .foregroundColor(foregroundColorText(accountsList.accounts[selectedAccountIndex].amount))
                            Text(String(accountsList.accounts[selectedAccountIndex].amount))
                                .font(.system(size: 24, weight: .bold))
                                .foregroundColor(foregroundColorText(accountsList.accounts[selectedAccountIndex].amount))
                        }
                        .padding(12)
                    }
                }
                .frame(maxWidth: .infinity) // Pour centrer horizontalement
                .font(.system(size: 25, weight: .bold))
                .background(Color("purple"))
                .foregroundColor(.white)
                VStack{
                    Text("Libellé :")
                        .font(.system(size: 25, weight: .bold))
                        .foregroundColor(Color(.black))
                        .padding(8)
                    TextField("Ex : Loyer...", text: $transactionName)
                        .submitLabel(.done)
                        .padding(18)
                        .padding(.horizontal, 8)
                        .font(.system(size: 25, weight: .bold))
                        .background(Color.white)
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.blue, lineWidth: 1)
                        )
                        .padding(.bottom,12)
                    DatePicker("Date : ", selection: $transactionDate)
                        .padding()
                        .foregroundColor(Color.black)
                        .font(.system(size: 20, weight: .medium))
                        .frame(width: nil, height: nil, alignment: .trailing)
                        .multilineTextAlignment(.center)
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.blue, lineWidth: 1)
                        )
                        .padding(.bottom,12)
                }
            }
            HStack {
                Text("Montant :")
                    .font(.system(size: 25, weight: .bold))
                    .foregroundColor(Color(.black))
                    .padding(8)
                TextField("0.00", text: $textFieldAmount)
                    .keyboardType(.numbersAndPunctuation)
                    .submitLabel(.done)
                    .background(Color.white)
                    .foregroundColor(Color.black.opacity(1.5))
                    .font(.system(size: 40, weight: .semibold))
                    .frame(width: nil, height: nil, alignment: .trailing)
                    .multilineTextAlignment(.center)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.blue, lineWidth: 1)
                    )
                if selectedAccountIndex > -1 {
                    Text(accountsList.accounts[selectedAccountIndex].currency.rawValue)
                        .font(.system(size: 24, weight: .light))
                }
            }
            .padding(.bottom, 12)


            MainButton(title: "Ajouter") {
                
                var counter = 0
                var alertMessage = ""
                
                if selectedAccountIndex == -1 {
                    counter += 1
                    alertMessage += "\n\(counter) - Sélectionner un compte!\n"
                }
                
                if transactionName.isEmpty {
                    counter += 1
                    alertMessage += "\n\(counter) - Nommer cette transaction!\n"
                }
                
                if Float(textFieldAmount) == nil || Float(textFieldAmount) == 0 {
                    counter += 1
                    alertMessage += "\n\(counter) - Saisir un montant!\n"
                }
                
                
                // EASTER EGGS pour rigoler :-)))
                if counter != 0 {
                    counter += 1
                    alertMessage += "\nEt \(counter) - Faire le café! Merci!\n"
                }
                
                
                if !alertMessage.isEmpty {
                    // Affichez l'alerte en définissant la variable alert
                    alert = AlertData(title: "Attention !", message: alertMessage)
                } else {
                    // Effectuez votre logique ici si aucune alerte n'est nécessaire
                    let newTransaction = Transaction(
                        label: transactionName,
                        amount: Float(textFieldAmount) ?? 0.0,
                        currency: accountsList.accounts[selectedAccountIndex].currency,
                        date: transactionDate
                    )
                    // Ajout de la transaction au compte
                    accountsList.accounts[selectedAccountIndex].transactions.append(newTransaction)
                    
                    DispatchQueue.global(qos: .background).async {
                        dataFileManager.dataFileSave(accounts: accountsList.accounts) { result in
                            if case .failure(let error) = result {
                                fatalError(error.localizedDescription)
                            } else {
                                completionHandler?(true)
                            }
                        }
                    }
                    
                    presentationMode.wrappedValue.dismiss()
                }
            }
            // Utilisez l'alerte en fonction de l'état de la variable alert
            .alert(item: $alert) { alertData in
                Alert(
                    title: Text(alertData.title),
                    message: Text(alertData.message),
                    primaryButton: .destructive(Text("OK"), action: {
                    }), secondaryButton: .cancel(Text("Annuler"))
                )
            }
        }
        .padding()
        .padding(.top, 32)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
        .background(Color("grey"))
        .sheet(isPresented: $isPresentingNewAccountScreen) {
            AccountCreationView { newAccount in
                accountsList.accounts.append(newAccount)
            }
        }
    }
    
    
    func foregroundColorText(_ value: Float) -> Color {
        if value == 0 {
            return .black
        } else if value == 0 {
            return .black
        } else if value > 0 {
            return .green
        } else {
            return Color(.red)
        }
    }
    
}
