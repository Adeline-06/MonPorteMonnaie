//
//  CalculationsServiceTests.swift
//  CalculationsServiceTests
//
//  Created by Adeline GIROIX on 25/09/2023.
//

import XCTest
@testable import MonPorteMonnaie

final class CalculationsServiceTests: XCTestCase {

    private var sut_Calculation: CalculationsService!
    private var sut_accountsList: AccountsList!


    //=====================================================
    // function SetUp
    //=====================================================
    override func setUpWithError() throws {
        // sut means System Under Test.
        sut_Calculation = CalculationsService()
        sut_accountsList = AccountsList()

    }

    //=====================================================
    // function TearDown
    //=====================================================
    override func tearDownWithError() throws {
        sut_Calculation = nil
        sut_accountsList = nil
    }


    //=====================================================
    // function testCalculationOfAnAccountInitialAmount
    // return the Initial Amount of an Accouts created.
    //=====================================================
    func testCalculationOfAnAccountInitialAmount() {

        // Given (Arrange) in SetUp function

        let newAccount = Account(
            iconName: "icon_001",
            name: "Test001",
            initialAmount: 5555.55,
            transactions: [],
            currency: Currency.euro
        )

        // When (Act)

        let initialAmount = sut_Calculation.calculationOfAnAccountInitialAmount(currentAccount: newAccount)

        let expected = " 5555.55 €"

        // Then (Assert)

        XCTAssertEqual(initialAmount, expected)
    }

    //=====================================================
    // function calculationOfComputedPropertieAccountAmount
    // return the computered propertie Amount of an any Account (initialAmount + transactions).
    //=====================================================
    func testCalculationOfComputedPropertieAccountAmount() {

        // Given (Arrange) in SetUp function

        let account001 = Account(
            iconName: "icon_001",
            name: "Test001",
            initialAmount: 1000.00,
            transactions: [],
            currency: Currency.euro
        )
        sut_accountsList.accounts.append(account001)

        let transaction01 = Transaction(
            label: "transaction01",
            amount: 500,
            currency: Currency.euro,
            date: Date.now
        )
        sut_accountsList.accounts[0].transactions.append(transaction01)

        let transaction02 = Transaction(
            label: "transaction02",
            amount: 1500,
            currency: Currency.euro,
            date: Date.now
        )
        sut_accountsList.accounts[0].transactions.append(transaction02)

        // When (Act)

        let valueAmountAccountGiven = sut_Calculation.calculationTotalAmountOfOneAccount(currentAccount: account001)

        // integrity
        let reCalculatedTotal = sut_Calculation.testSuccessIntegrityfullCalculationTotalOfOneAccount(currentAccount: account001)

        let expected = reCalculatedTotal

        // Then (Assert)

        XCTAssertEqual(valueAmountAccountGiven, expected)
    }


    //=====================================================
    // function testCalculationTotalAmountOfOneAccount
    // returns the amount propertie + currency icon of any current Account.
    //=====================================================
    func testCalculationTotalAmountOfOneAccount() {

        // Given (Arrange) in SetUp function

        let account001 = Account(
            iconName: "icon_001",
            name: "Test001",
            initialAmount: 1000.00,
            transactions: [],
            currency: Currency.euro
        )
        sut_accountsList.accounts.append(account001)

        let transaction01 = Transaction(
            label: "transaction01",
            amount: 500,
            currency: Currency.euro,
            date: Date.now
        )
        sut_accountsList.accounts[0].transactions.append(transaction01)

        let transaction02 = Transaction(
            label: "transaction02",
            amount: 1500,
            currency: Currency.euro,
            date: Date.now
        )
        sut_accountsList.accounts[0].transactions.append(transaction02)

        // When (Act)

        let totalAmount = sut_Calculation.calculationTotalAmountOfOneAccount(currentAccount: account001)

        let expected = "3000.00 €"

        // Then (Assert)

        XCTAssertEqual(totalAmount, expected)
    }


    //=====================================================
    // function testCalculationOfGrantTotalOfAllAccountsAmounts()
    // return the grant total Amount of all Accouts Amounts in the AccountsList.
    //=====================================================
    func testCalculationOfGrantTotalOfAllAccountsAmounts() {

        // Given (Arrange)

        let account001 = Account(
            iconName: "icon_001",
            name: "Test001",
            initialAmount: 1000.00,
            transactions: [],
            currency: Currency.euro
        )
        sut_accountsList.accounts.append(account001)

        let account002 = Account(
            iconName: "icon_002",
            name: "Test002",
            initialAmount: 2000.00,
            transactions: [],
            currency: Currency.euro
        )
        sut_accountsList.accounts.append(account002)

        let account003 = Account(
            iconName: "icon_003",
            name: "Test003",
            initialAmount: 3000.00,
            transactions: [],
            currency: Currency.euro
        )
        sut_accountsList.accounts.append(account003)

        // When (Act)

//        let calculation = Calculation()

        let total = sut_Calculation.calculationOfGrantTotalOfAllAccountsAmounts(currentAccountsList:  sut_accountsList)

        let expected = "6000.00 €"

        // Then (Assert)

        XCTAssertEqual(total, expected)
    }


    //=====================================================
    // function testSuccessfullCalculationTotalOneAccount()
    // returns "Solde : " + amount + currency icon of any current Account.
    //=====================================================
    func testCalculationOfBalanceOfOneAccount() {

//        let accountsListTest = AccountsList()

        // Given (Arrange)

        let account001 = Account(
            iconName: "icon_001",
            name: "Test001",
            initialAmount: 1000.00,
            transactions: [],
            currency: Currency.euro
        )

        // When (Act)

        let accountBalance = sut_Calculation.calculationOfBalanceOfOneAccount(currentAccount: account001)

        let expected = "Solde : 1000.00 €"

        // Then (Assert)

        XCTAssertEqual(accountBalance, expected)
    }


    //=====================================================
    // function testcalculationOfNewAccountAmount()
    // returns "Solde : " + amount + currency icon of any current Account.
    //=====================================================
    func testCalculationOfNewAccountAmount() {

        // Given (Arrange)

        let amountEntered = "5000.00"

        // When (Act)

        let newAmount = sut_Calculation.calculationOfNewAccountAmount(amountEntered: amountEntered)

        let expected = "Solde : 5000.00 €"

        // Then (Assert)

        XCTAssertEqual(newAmount, expected)
    }

    //=====================================================
    // function testcalculationOfNewAccountAmount()
    // returns "Solde : " + amount + currency icon of any current Account.
    //=====================================================
    func testCalculationOfNewAccountAmountClosure() {

        // Given (Arrange)

        let amountEntered = ""

        // When (Act)

        let newAmount = sut_Calculation.calculationOfNewAccountAmount(amountEntered: amountEntered)

        let expected = "Solde : 0.00 €"

        // Then (Assert)

        XCTAssertEqual(newAmount, expected)
    }

    //=====================================================
    // function testCalculationOfTransactionAmount()
    // returns "current transaction amount + currency icon.
    //=====================================================
    func testCalculationOfTransactionAmount() {

        // Given (Arrange)

        let transaction01 = Transaction(
            label: "transaction01",
            amount: 500,
            currency: Currency.euro,
            date: Date.now
        )

        // When (Act)

        let newAmount = sut_Calculation.calculationOfTransactionAmount(currentTransaction: transaction01)

        let expected = "500.00 €"

        // Then (Assert)

        XCTAssertEqual(newAmount, expected)
    }


    //=====================================================
    // function testCalculationOfAccountSelector()
    // returns the Selected Account Amount + currency icon of the current index seclected account.
    //=====================================================
    func testCalculationOfAccountSelector() {

        // Given (Arrange)

        let account001 = Account(
            iconName: "icon_001",
            name: "Test001",
            initialAmount: 1000.00,
            transactions: [],
            currency: Currency.euro
        )
        sut_accountsList.accounts.append(account001)

        // When (Act)

        let accountSelected = sut_Calculation.calculationOfAccountSelector(accountLlist: sut_accountsList, selectedAccountIndex: 0)

        let expected = "(1000.00 €)"

        // Then (Assert)

        XCTAssertEqual(accountSelected, expected)
    }


    //=====================================================
    // function testCalculationOfAccountSelectorAmount()
    // returns the Selected Account Amount + currency icon of the current account.
    //=====================================================
    func testCalculationOfAccountSelectorAmount() {

        // Given (Arrange)

        let account001 = Account(
            iconName: "icon_001",
            name: "Test001",
            initialAmount: 1000.00,
            transactions: [],
            currency: Currency.euro
        )
        sut_accountsList.accounts.append(account001)

        // When (Act)

        let AccountAmount = sut_Calculation.calculationOfAccountSelectorAmount(currentAccount: account001)

        let expected = "(1000.00 €)"

        // Then (Assert)

        XCTAssertEqual(AccountAmount, expected)
    }



    //=====================================================
    // function testSuccessIntegrityfullCalculationTotalOneAccount()
    // test if the calculated propertie "amount" from account is correct.
    //=====================================================
    func testSuccessIntegrityfullCalculationTotalOneAccount() {

//        let accountsListTest = AccountsList()

        // Given (Arrange)

        let account001 = Account(
            iconName: "icon_001",
            name: "Test001",
            initialAmount: 1000.00,
            transactions: [],
            currency: Currency.euro
        )
        sut_accountsList.accounts.append(account001)

        let transaction01 = Transaction(
            label: "transaction01",
            amount: 500,
            currency: Currency.euro,
            date: Date.now
        )
        sut_accountsList.accounts[0].transactions.append(transaction01)

        let transaction02 = Transaction(
            label: "transaction02",
            amount: 1500,
            currency: Currency.euro,
            date: Date.now
        )
        sut_accountsList.accounts[0].transactions.append(transaction02)

        // When (Act)

//        let calculation = Calculation()

        let valueAmountAccountGiven = sut_Calculation.calculationTotalAmountOfOneAccount(currentAccount: account001)

        let reCalculatedTotal = sut_Calculation.testSuccessIntegrityfullCalculationTotalOfOneAccount(currentAccount: account001)

        // Then (Assert)

        XCTAssertEqual(valueAmountAccountGiven, reCalculatedTotal)
    }


}
