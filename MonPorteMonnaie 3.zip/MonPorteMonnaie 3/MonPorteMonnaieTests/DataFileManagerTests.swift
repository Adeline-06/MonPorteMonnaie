//
//  DataFileManagerTests.swift
//  DataFileManagerTests
//
//  Created by Adeline GIROIX on 18/09/2023.
//

#warning("v05")

import XCTest
@testable import MonPorteMonnaie

final class DataFileManagererTests: XCTestCase {
    
    private var sut_dataFileManager: DataFileManager!
    private var sut_accountsList: AccountsList!
//    private var sut_accounts: [Account]!
    
    //=====================================================
    // function SetUp
    //=====================================================
    override func setUpWithError() throws {
        // sut means System Under Test.
        sut_dataFileManager = DataFileManager()
        sut_accountsList = AccountsList()
    }
    
    //=====================================================
    // function TearDown
    //=====================================================
    override func tearDownWithError() throws {
        sut_dataFileManager = nil
        sut_accountsList = nil
    }
    
    //=====================================================
    // function testSaveDataFileSuccess()
    // test the proced to the saving of the persistant file accouts file
    //=====================================================
    func testSaveDataFileSuccess() {
        
        let account001 = Account(
            iconName: "icon_001",
            name: "Test001",
            initialAmount: 1000.00,
            transactions: [],
            currency: Currency.euro
        )
        sut_accountsList.accounts.append(account001)

        let account002 = Account(
            iconName: "icon_002",
            name: "Test002",
            initialAmount: 2000.00,
            transactions: [],
            currency: Currency.euro
        )
        sut_accountsList.accounts.append(account002)

        let account003 = Account(
            iconName: "icon_003",
            name: "Test003",
            initialAmount: 3000.00,
            transactions: [],
            currency: Currency.euro
        )
        sut_accountsList.accounts.append(account003)
            let expectation = self.expectation(description: "Sauvegarde des données réussie")
            
        let accountsResult = sut_accountsList.accounts // Créez un tableau d'accounts pour les tests

        sut_dataFileManager.dataFileSave(accounts: accountsResult) { result in
                switch result {
                case .failure(let error):
                    XCTFail("La sauvegarde des données a échoué avec l'erreur : \(error)")
                case .success(let count):
                    XCTAssertEqual(count, self.sut_accountsList.accounts.count, "Le compte de sauvegarde ne correspond pas au nombre d'accounts")
                }
                expectation.fulfill()
            }
            
            waitForExpectations(timeout: 5.0, handler: nil)
        }
    
    
    //=====================================================
    // function testLoadDataFileSuccess()
    // test the proced to the loading of the persistant file accouts file
    //=====================================================
//    func testLoadDataFileSuccess() {
//        func testLoadDataFileSuccess() {
//                let expectation = self.expectation(description: "Chargement des données réussi")
//
//            sut_dataFileManager.dataFileLoad { result in
//                    switch result {
//                    case .failure(let error):
//                        XCTFail("Le chargement des données a échoué avec l'erreur : \(error)")
//                    case .success(let accounts):
//                        XCTAssertFalse(accounts.isEmpty, "Le tableau d'accounts ne doit pas être vide")
//                    }
//                    expectation.fulfill()
//                }
//
//                waitForExpectations(timeout: 5.0, handler: nil)
//            }
//    }
    
    
    func testLoadDataFileSuccess() {
        // Créez un exemple de données JSON valide pour les tests
        let validJSON = """
        [
            {
                "iconName": "icon_001",
                "name": "Test001",
                "initialAmount": 1000.00,
                "transactions": [],
                "currency": "euro"
            },
            {
                "iconName": "icon_002",
                "name": "Test002",
                "initialAmount": 2000.00,
                "transactions": [],
                "currency": "euro"
            },
            {
                "iconName": "icon_003",
                "name": "Test003",
                "initialAmount": 3000.00,
                "transactions": [],
                "currency": "euro"
            }
        ]
        """
        
        // Créez un fichier temporaire pour simuler la lecture depuis le disque
        let tempFileURL = FileManager.default.temporaryDirectory.appendingPathComponent("test_accounts.json")
        
        do {
            try validJSON.write(to: tempFileURL, atomically: true, encoding: .utf8)
        } catch {
            XCTFail("Erreur lors de la création du fichier JSON de test : \(error)")
        }
        
        let dataFileManager = DataFileManager()
        
        let expectation = self.expectation(description: "Chargement des données réussi")
        
        dataFileManager.dataFileLoad { result in
            switch result {
            case .failure(let error):
                XCTFail("Le chargement des données a échoué avec l'erreur : \(error)")
            case .success(let accounts):
                XCTAssertFalse(accounts.isEmpty, "Le tableau d'accounts ne doit pas être vide")
                XCTAssertEqual(accounts.count, 3, "Le nombre d'accounts chargés ne correspond pas")
                // Vous pouvez effectuer d'autres vérifications sur les données chargées ici
            }
            expectation.fulfill()
        }
        
        waitForExpectations(timeout: 5.0, handler: nil)
    }
    
}


